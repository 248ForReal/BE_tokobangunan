const Users = require("../api/v1/adminn/AdminModel.js");

const verifyUser = async (req, res, next) => {
  if (!req.session.userId)
    return res.status(401).json({
      msg: "Please login to your account!",
    });

  const user = await Users.findOne({
    where: {
      uuid: req.session.userId,
    },
  });

  if (!user)
    return res.status(404).json({
      msg: "User does not exist",
    });

  req.userId = user.id;
  req.role = user.role;
  next();
};

const adminRole = async (req, res, next) => {
  const user = await Users.findOne({
    where: {
      uuid: req.session.userId,
    },
  });

  if (!user)
    return res.status(404).json({
      msg: "User does not exist",
    });

  if (user.role !== "admin")
    return res.status(403).json({
      msg: "Cannot access",
    });
  next();
};

const kasirRole = async (req, res, next) => {
    const user = await Users.findOne({
      where: {
        uuid: req.session.userId,
      },
    });
  
    if (!user)
      return res.status(404).json({
        msg: "User does not exist",
      });
  
    if (user.role !== "kasir")
      return res.status(403).json({
        msg: "Cannot access",
      });
    next();
  };

module.exports = {
  verifyUser,
  adminRole,
  kasirRole
};